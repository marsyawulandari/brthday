const surpriseBtn = document.getElementById('surpriseBtn');
const blowBtn = document.getElementById('blowBtn');
const cake = document.querySelector('.cake');
const wishText = document.getElementById('wishText');
const confettiLayer = document.getElementById('confetti-layer');

function launchConfetti(amount = 100) {
  const colors = ['#f5a9c0', '#c8b6ed', '#ffd18c', '#a9d9d1', '#ef8eac', '#fff'];
  for (let i = 0; i < amount; i++) {
    const piece = document.createElement('span');
    piece.className = 'confetti';
    piece.style.left = Math.random() * 100 + 'vw';
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDuration = (2.5 + Math.random() * 3) + 's';
    piece.style.animationDelay = (Math.random() * .7) + 's';
    piece.style.transform = `rotate(${Math.random() * 360}deg)`;
    confettiLayer.appendChild(piece);
    setTimeout(() => piece.remove(), 6500);
  }
}

surpriseBtn.addEventListener('click', () => {
  launchConfetti(130);
  document.querySelector('.photo-section').scrollIntoView({ behavior: 'smooth' });
  surpriseBtn.textContent = 'Surprise buat kamu! 💗';
});

blowBtn.addEventListener('click', () => {
  cake.classList.add('blown');
  wishText.textContent = 'Yay! Semoga semua doa baikmu segera terwujud. 🤍✨';
  blowBtn.textContent = 'Lilin sudah ditiup ♡';
  launchConfetti(75);
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
